/**************************************************************************
 *                      Annapolis Micro Systems Inc.                      *
 *                         190 Admiral Cochrane                           *
 *                              Suite 130                                 *
 *                         Annapolis, MD  21401                           *
 **************************************************************************/

/**************************************************************************
 *  File       :  wfoss.h
 *  Project    :  Wildforce
 *  Description:  Runtime library for Wildforce
 *  Author     :  M. Gray
 *  Copyright  :  Annapolis Micro Systems Inc., 1998
 *
 *  Notes
 *   o This is a central point for adding Operating System specific
 *     headers, to minimize updates to other .h and .c files in API 
 *    level ports.
 *
 **************************************************************************/

#ifndef __WFOSS_H__
#define __WFOSS_H__

/* 
 * NOTE: THIS DEFINE SHOULD BE SET TO MATCH THE OS THAT
 *       THIS FILE IS INSTALLED ON. THIS ENSURES THAT THE
 *       USER DOES NOT SELECT THE WRONG OS SUPPORT
 */

#ifndef _ULTRA_
#define _ULTRA_
#endif

/* ^^^^^^^^^^^^^^^^^^^
 * |||||||||||||||||||
 * OS SUPPORT SELECTED
 */

#if defined( WIN32 ) && (! defined(__DRV__))
#include <windows.h>
#endif

#ifndef WFAPI
#ifdef __cplusplus
#define WFAPI  extern "C"
#else
#define WFAPI  extern
#endif
#endif

#if defined( _ULTRA_ )
#include <sys/inttypes.h>
#include <sys/types.h>

#ifndef _MAX_PATH
#define _MAX_PATH (256)
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef CHAR
#define CHAR char
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

#ifndef USHORT
#define USHORT uint16_t
#endif

#ifndef WORD
#define WORD  uint16_t
#endif

#ifndef DWORD
#define DWORD uint32_t
#endif

#ifndef ULONG
#define ULONG DWORD
#endif

#ifndef LONG
#define LONG int32_t
#endif

#ifndef BOOL
#define BOOL unsigned char
#endif

#ifndef BOOLEAN
#define BOOLEAN int
#endif

#ifndef FLOAT
#define FLOAT   float
#endif

#ifndef LPVOID
#define LPVOID  void *
#endif

#ifndef PULONG
#define PULONG  ULONG *
#endif

#ifndef HANDLE
#define HANDLE  int
#endif

#endif /* _ULTRA_ */

#ifndef TRUE
#define TRUE    1
#endif

#ifndef FALSE
#define FALSE   0
#endif


#include <wfultra.h>

#endif /* sentinel */
